import { initializeApp } from 'firebase/app';
import { getAnalytics, isSupported } from 'firebase/analytics';

export const firebaseConfig = {
  apiKey: 'AIzaSyBkT6OzSUQtMOTvMyjimTlAQ7ZytopdcdI',
  authDomain: 'sm-sadi-ai-treading.firebaseapp.com',
  databaseURL: 'https://sm-sadi-ai-trading-platform-default-rtdb.firebaseio.com/',
  projectId: 'sm-sadi-ai-treading',
  storageBucket: 'sm-sadi-ai-treading.firebasestorage.app',
  messagingSenderId: '490451304506',
  appId: '1:490451304506:web:923966165b3324eb603503',
  measurementId: 'G-H16P5DRR87',
};

export const app = initializeApp(firebaseConfig);
export const analyticsPromise =
  typeof window !== 'undefined'
    ? isSupported().then((yes) => (yes ? getAnalytics(app) : null)).catch(() => null)
    : Promise.resolve(null);
